import 'package:flutter/cupertino.dart';
const Color colorSecondry = Color(0xff150355);
const Color colorPrimary = Color(0xffdd1177);
const Color colorBlue = Color(0xFF2562b2);
const Color colorGrey = Color(0xFF5c5c5c);
const Color colorlightGrey = Color(0xFFE0DEDE);
const Color colorBlack = Color(0xFF000417);
const Color colorWhite = Color(0xFFFFFFFF);
